jQuery(document).ready(function () {
    $(".site-nav-item a").mPageScroll2id({scrollSpeed: 800 });
    // $("button a").mPageScroll2id({scrollSpeed: 800});
});